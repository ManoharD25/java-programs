
class TypeConversion{
	
		public staic void main (String [] args){
		
		int i = (int)a;
		
		}

}